#!/bin/bash

# threshold=90

# echo $threshold

# echo threshold $threshold

# echo "Welcome to the program"

# threshold=90 # declaring a variable threshold with value 80

# echo "value of the threshold set is $threshold" # using the variable inside a print statement

# echo 'value of threshol is $threshold'

# current_path=$(pwd)

# echo " current path is $current_path"

# echo "$not_presentVariable"

# echo $USER


